/*
 * Generic converter template for a selected ASN.1 type.
 * Copyright (c) 2005, 2006, 2007 Lev Walkin <vlm@lionet.info>.
 * All rights reserved.
 * 
 * To compile with your own ASN.1 type, please redefine the PDU as shown:
 * 
 * cc -DPDU=MyCustomType -o myDecoder.o -c converter-sample.c
 */
#ifdef	HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>	/* for atoi(3) */
//#include <unistd.h>	/* for getopt(3) */
#include <string.h>	/* for strerror(3) */
//#include <sysexits.h>	/* for EX_* exit codes */
#include <errno.h>	/* for errno */
#include <BSMtype.h>
#include <asn_application.h>
#include <asn_internal.h>	/* for _ASN_DEFAULT_STACK_MAX */
#include <BasicVehicle.h>



int ret=10;
int iCnt=1; //msg Counter
int iTemp=5426;
char buf[1024]={NULL};
asn_enc_rval_t ec; /* Encoder return value */
asn_dec_rval_t rval;
size_t size=0; 
OCTET_STRING_t ost;
unsigned char h;
BasicVehicle veh;
char BSMmsg[45];
char BSMblob[38];
char * BSMstr;
int ii;
int main(int ac, char *av[]) {

	char* pByte = "5426";

	BSMtype_t * bsmType=0;
	bsmType = (BSMtype_t *) calloc(1, sizeof *bsmType );

    veh.TemporaryID = 12345 ;
	veh.DSecond = 100 ;
	veh.MsgCount = 1 ;
	veh.speed = 15.0 ;
	veh.heading = 90.0 ;
	veh.pos.latitude = -112.222 ;
	veh.pos.longitude = 32.2555 ;

	veh.angle = 0.0 ;
	veh.pos.elevation = 535 ;
	veh.pos.positionAccuracy = 0.5 ;
	veh.length = 6.0 ;
	veh.width = 2.3 ;
	veh.weight = 1043.26 ;
	veh.accel.latAcceleration = 0.02 ;
   	veh.Vehicle2BSM(BSMmsg);
	bsmType->msgID=2;
	
		for(int i=7;i<45;i++)  //copy the the BSM Blob
		{
			BSMblob[i-7]=BSMmsg[i];
		}
		

	
	ret=OCTET_STRING_fromBuf(&bsmType->bsmBlob,BSMblob,38);
	//bsmType->tempID.buf = 8<<(5);
	
//	printf("size of accuracy: %c\n",bsmType->tempID.buf[0]);
   
	ec = der_encode_to_buffer(&asn_DEF_BSMtype, bsmType,buf,1024);
	for( ii=0;ii<100;ii++)
		printf("%x\t",(uint8_t) buf[ii]);


	rval = ber_decode(0, &asn_DEF_BSMtype,(void **)&bsmType, buf, size);
		xer_fprint(stdout, &asn_DEF_BSMtype, bsmType);

	
	return 0;
}
