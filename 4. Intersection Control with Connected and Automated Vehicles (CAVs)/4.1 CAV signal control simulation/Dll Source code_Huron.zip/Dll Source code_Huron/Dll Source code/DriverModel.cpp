/*==========================================================================*/
/*  DriverModel.cpp                                  DLL Module for VISSIM  */
/*                                                                          */
/*  Interface module for external driver models.                            */
/*  Dummy version that simply sends back VISSIM's suggestions to VISSIM.    */
/*                                                                          */
/*  Version of 2010-03-02                                   Lukas Kautzsch  */
/*==========================================================================*/

// drivermodel.cpp : Defines the initialization routines for the DLL.

// Vissim connect to OBEs through UDP: send BSM to OBE
// OBE needs "obu_infusion" running

// Need directory "map" to save BSMs locally.


// NEED to Read in Configure information of IP address and IP port from "ConfigInfo.txt"

// Which contains receiver's(OBE) IP and port, and the x-y range for collecting data in vissim


#include "DriverModel.h"
#include "stdafx.h"
#include "geoCoord.h"
#include "BasicVehicle.h"
#include "ListHandle.h"

#include <winsock2.h>
#include <fstream>
#include <stdio.h>
#include <vector>
#include <sstream>
#include <assert.h>
#include "math.h"
#include "time.h"
#include <string.h>
#include <stdio.h>

/*==========================================================================*/

static std::string computerName="localhost";
int portNumber;
char IPAddress[20];
string lineread;
double x_range,y_range;
static  SOCKET socketsc_connect = NULL;
static  SOCKET socketsc_sock = NULL;
struct sockaddr_in sa;   //sa: sender address
struct sockaddr_in ra;   //sa: reveiver address
static  double simTime = 0;

char buffer[256];
char buffPP[256];
BasicVehicle veh, vehIn ;
char blobOut[BSM_BlOB_SIZE] ;
char BSMmsgOut[BSM_MSG_SIZE];
int temp_int;
long dsecond;
char BSMInfoFile[256];

LinkedList<IDMSGcnt> ReqList;
IDMSGcnt Temp_IDMsgCnt;


// ASN1 Convertor variables 

#include "BSM.h"
#include "asn_application.h"
#include "asn_internal.h"	/* for _ASN_DEFAULT_STACK_MAX */
#include "OCTET_STRING.h"

char buf[66]={NULL};
asn_enc_rval_t ec; /* Encoder return value */
asn_dec_rval_t rval;
size_t size=0; 
OCTET_STRING_t ost;
int ret;
BSM_t * bsmType=0;

extern "C" { int _afxForceUSRDLL; }

void CreateVehMsg(int tempID,int dSecond,int msgCount,double lat,double lon,double heading,double speed,double altitude)
{

	veh.TemporaryID = tempID ;
	veh.DSecond = dSecond ;
	veh.MsgCount = msgCount ;
	veh.motion.speed = speed ;
	veh.motion.heading = heading ;
	veh.pos.latitude = lat ;
	veh.pos.longitude = lon ;

	veh.motion.angle = 0.0 ;
	veh.pos.elevation = altitude;
	veh.pos.positionAccuracy = 0.5 ;
	veh.length = 6.0 ;
	veh.width = 2.3 ;
	
	veh.motion.accel.latAcceleration = 0.02 ;

}

geoCoord geoPoint ;

#define PI 3.1415926535

/*============================================================*/

//This coordinate is the center of the intersection
double	lon_degree; 
double	lon_minutes;   
double	lon_seconds;

double	lat_degree; 
double	lat_minutes;  
double	lat_seconds;

double	altitude; 


double g_long, g_lat, g_altitude ;
double x_grid, y_grid, z_grid ;
double longitude, latitude;
double x_cal,y_cal,z;  // The x & y applied in coordination conversion: x=vehicle_y,y=vehicle_x


int counter=0,timeCnt=0;


/*==========================================================================*/

double  desired_acceleration = 0.0;
double  desired_lane_angle   = 0.0;
long    active_lane_change   = 0;
long    rel_target_lane      = 0;
double  desired_velocity     = 0.0;
long    turning_indicator    = 0;
long    vehicle_color        = RGB(0,0,0);

/*==========================================================================*/
long msgCnt=0;
double vehicle_time_new = 0;
double vehicle_time_cur = 0;
long vehicle_id_new = 0;
long vehicle_id_cur = 0;

double dx=0.0,dy=0.0;
double vehicle_x = 0;
double vehicle_y = 0;
double vehicle_z=0.0;
double veh_rear_x=0;
double veh_rear_y=0;
double veh_speed=0.0;
double veh_accel=0.0;
double veh_angle=0.0;
double veh_heading=0.0;
double veh_length=0.0;
double veh_width=0.0;
char bufferPP [50];
int currentlane = 0;
int pre_sendtime = 0;
FILE *fp;
FILE* fp_BSM;
FILE* fp_Config;
fstream fs_config;

char temp_log[256];
/*==========================================================================*/

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

/*--------------------------------------------------------------------------*/

static  int write_data (SOCKET s,  /* connected socket */
						char *buf, /* pointer to the buffer */
						int n      /* number of characters (bytes) we want */)
{
	int bcount=0; /* counts bytes written */
	int len=sizeof(SOCKADDR_IN); // SOCKADDR

	bcount=sendto(s, (char *)(buf), n, 0,(SOCKADDR*)&sa,len);

	if(bcount!= n)
	{
		sprintf(buffPP,"***Write data not Sending the right msg");
		MessageBoxA(NULL,buffPP,"***Write data ERROR***",MB_OK);
		return -1;
	}
	else
	{
		return bcount;
	}	

}

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

static  int read_data (SOCKET s,  /* connected socket */
					   unsigned char *buf, /* pointer to the buffer */
					   int n      /* number of characters (bytes) we want */)
{
	int bcount; /* counts bytes read */
	int br;     /* bytes read this pass */

	bcount = 0;
	br = 0;
	while (bcount < n) {             /* loop until full buffer */
		if ((br = recv(s, (char *)(buf), n - bcount, 0)) > 0) {
			bcount += br;                /* increment byte counter */
			buf += br;                   /* move buffer ptr for next read */
		}
		else if (br < 0)               /* signal an error to the caller */
			return -1;
	}
	//sprintf(buffPP,"***read data***Current counter number: %d",counter);
	//MessageBoxA(NULL,buffPP,"***Read data***",MB_OK);
	//counter++;
	return bcount;
}

/*--------------------------------------------------------------------------*/

static  SOCKET establish (void)
{
	SOCKET s;
	//struct sockaddr_in sa;   //sa: sever address
	struct hostent *hp;
	char broadcast=1;
	int iOptLen = sizeof(char);

	//s = socket(AF_INET, SOCK_STREAM, IPPROTO_UDP);        /* create the socket */
	s=socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(s <=0 )        /* create the socket */
	{
		sprintf(buffPP,"***Socket UDP Failed***Current counter number: %d ",counter);
		//MessageBoxA(NULL,buffPP,"***Socket UDP Failed!***",MB_OK);	counter++;	exit(1);
	} 
	memset(&sa, 0, sizeof(sa)); /* clear our address */

	hp = gethostbyname(computerName.c_str());   /* get our address info */

	if (hp == NULL)                             /* we don't exist !? */
		return(INVALID_SOCKET);
	//sa.sin_family = hp->h_addrtype;             /* this is our host address */
	sa.sin_family=AF_INET;

	//sa.sin_port = htons(portNumber);            /* this is our port number */	

	// Read in Configure information of IP address and IP port
	// This has to be done here in the STATIC function. ****Important****
		fs_config.open ("./ConfigInfo.txt", fstream::in);

		getline(fs_config,lineread);
		sprintf(IPAddress,"%s",lineread.c_str());

		getline(fs_config,lineread);
		sscanf(lineread.c_str(),"%d",&portNumber);

		fs_config.close();

	sa.sin_port = htons((unsigned short)portNumber); 

	sa.sin_addr.s_addr = inet_addr((const char*) (IPAddress));		


	return(s);
}

/*--------------------------------------------------------------------------*/


/*==========================================================================*/

//BOOL APIENTRY DllMain (HANDLE  hModule, 
//                       DWORD   ul_reason_for_call, 
//                       LPVOID  lpReserved)
//{
//  switch (ul_reason_for_call) {
//      case DLL_PROCESS_ATTACH:
//      case DLL_THREAD_ATTACH:
//      case DLL_THREAD_DETACH:
//      case DLL_PROCESS_DETACH:
//         break;
//  }
//  return TRUE;
//}

/*==========================================================================*/

DRIVERMODEL_API  int  DriverModelSetValue (long   type, 
                                           long   index1,
                                           long   index2,
                                           long   long_value,
                                           double double_value,
                                           char   *string_value)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
  /* Sets the value of a data object of type <type>, selected by <index1> */
  /* and possibly <index2>, to <long_value>, <double_value> or            */
  /* <*string_value> (object and value selection depending on <type>).    */
  /* Return value is 1 on success, otherwise 0.                           */



  switch (type) {
    case DRIVER_DATA_PATH                   :
    case DRIVER_DATA_TIMESTEP               :
    case DRIVER_DATA_TIME                   :
      sprintf (bufferPP, "DATA_TIME is %f ",double_value);
	  vehicle_time_new = double_value;
	  vehicle_time_cur = vehicle_time_new;
	  return 1;
    case DRIVER_DATA_VEH_ID                 :
     vehicle_id_new = long_value;
	 vehicle_id_cur = vehicle_id_new;
	 return 1;	
    case DRIVER_DATA_VEH_LANE               :
	 return 1;
    case DRIVER_DATA_VEH_ODOMETER           :
	 return 1;
    case DRIVER_DATA_VEH_LANE_ANGLE         :
	 veh_angle=double_value;
	 return 1;
    case DRIVER_DATA_VEH_LATERAL_POSITION   :
    case DRIVER_DATA_VEH_VELOCITY           :
     veh_speed = double_value;
	 return 1;
    case DRIVER_DATA_VEH_ACCELERATION       :
     veh_accel=double_value;
	 return 1;
    case DRIVER_DATA_VEH_LENGTH             :
	 veh_length=double_value;
	 return 1;
    case DRIVER_DATA_VEH_WIDTH              :
     veh_width=double_value;
	 return 1;
    case DRIVER_DATA_VEH_WEIGHT             :
    case DRIVER_DATA_VEH_MAX_ACCELERATION   :
      return 1;
    case DRIVER_DATA_VEH_TURNING_INDICATOR  :
      turning_indicator = long_value;
      return 1;
    case DRIVER_DATA_VEH_CATEGORY           :
    case DRIVER_DATA_VEH_PREFERRED_REL_LANE :
    case DRIVER_DATA_VEH_USE_PREFERRED_LANE :
      return 1;
    case DRIVER_DATA_VEH_DESIRED_VELOCITY   :
      desired_velocity = double_value;
      return 1;
    case DRIVER_DATA_VEH_X_COORDINATE       :
	  vehicle_x = double_value;
	  return 1;
    case DRIVER_DATA_VEH_Y_COORDINATE       :
      vehicle_y = double_value;
	    return 1;
    case DRIVER_DATA_VEH_TYPE               :
	   return 1;
	case DRIVER_DATA_VEH_REAR_X_COORDINATE  :
      veh_rear_x=double_value;
	  return 1;
    case DRIVER_DATA_VEH_REAR_Y_COORDINATE  :

	   veh_rear_y=double_value;
		dx=vehicle_x-veh_rear_x;
		dy=vehicle_y-veh_rear_y;
		veh_heading=atan2(dy,dx)*180.0/PI;  
		x_cal=(vehicle_x+veh_rear_x)/2;
		y_cal=(vehicle_y+veh_rear_y)/2;
		veh_heading=90.0-veh_heading;

		geoPoint.local2ecef(y_cal, x_cal, 0.0, &x_grid, &y_grid, &z_grid) ; // Third argument z=0.0 for vissim

		geoPoint.ecef2lla(x_grid, y_grid, z_grid, &g_long, &g_lat, &g_altitude) ;

		if(veh_heading<0)
		{
			veh_heading=veh_heading+360.0;
		}

		

	
		//---------The following for sending BSM---------------------------//
	
	//if((fabs(vehicle_x)<200.0 && fabs(vehicle_y)<200.0))    // Decide the range of getiing BSM
	//if(int(vehicle_time_new*10)%10==0 && (fabs(vehicle_x)<120 && fabs(vehicle_y)<120))
	//if(int(vehicle_time_new*10)%10==0 && vehicle_time_new>5.0 &&  vehicle_time_new<10.0)
	//{		
		msgCnt=0;  //since the ID is not changing now, msgCnt is not used here!!
		dsecond=(long(vehicle_time_new*10))%600*100; // TO GET THE million second of current simulaiton time
		bsmType = (BSM_t *) calloc(1, sizeof *bsmType );
		CreateVehMsg(vehicle_id_new, dsecond, msgCnt, g_lat, g_long, veh_heading, veh_speed, altitude);
	   	veh.VehicleToBSM(blobOut );
		bsmType->msgID=2;
		ret=OCTET_STRING_fromBuf(&bsmType->bsmBlob,blobOut,38);
		ec = der_encode_to_buffer(&asn_DEF_BSM, bsmType,BSMmsgOut,BSM_MSG_SIZE);   //   Copyright (c) 2003-2013 Lev Walkin <vlm@lionet.info>  http ://lionet.info/asn1c/asn1c-license.txt
		timeCnt++;
		if( (temp_int=sendto(socketsc_connect,BSMmsgOut,BSM_MSG_SIZE, 0,(SOCKADDR*)&sa,sizeof(SOCKADDR_IN)))!=BSM_MSG_SIZE )
		{
			fprintf(fp,"send error... %d\n ",temp_int);

		}


    

		/////********** LOGING *************/////

		
		//fp = fopen(cLogFileName, "a");

		//if (fp == NULL)
		//{
		//	MessageBox(NULL,"FILE pointer init failure!","xxx",MB_OK);
		//	exit(1);
		//}
		//sprintf(temp_log,"\n VehicleINFOMRATIOONNNN  %d , %5.2f, %d , %3.8f , %3.8f , %2.4f , %2.4f \n", temp_int ,	vehicle_time_new,veh.TemporaryID,veh.pos.latitude, veh.pos.longitude,veh.speed, veh.heading);

		//
		//fprintf(fp,temp_log);
		//
		//sprintf(temp_log,"\n %d\t%ld\t%.3lf\t%.8lf\t%.8lf\t%.4f\t%.4f\n",msgCnt, vehicle_id_new, vehicle_time_new, g_lat, g_long, veh_speed,veh_heading);

		//             //sprintf(buffPP,"***Current Position: %d, %6.2f, %6.2f",vehicle_id_new,vehicle_x,vehicle_y);
				//	 sprintf(buffPP,"***Current Pos %d , %x", temp_int,BSMmsgOut[2]);
		        //   MessageBoxA(NULL,buffPP,"***POSITION***",MB_OK);
		//             //msgCnt=UpdateReqList(ReqList,vehicle_id_new)%128;

		//fprintf(fp,temp_log);
		//fclose(fp);
		
      		///********** END of LOGGING ************///

	//---------End of The following for sending BSM for Savari---------------------------//
	

	return 1;
    //case DRIVER_DATA_VEH_TYPE               :
    //  return 1;
    case DRIVER_DATA_VEH_COLOR              :
      vehicle_color = long_value;
      return 1;
    case DRIVER_DATA_VEH_CURRENT_LINK       :
      return 0; /* (To avoid getting sent lots of DRIVER_DATA_VEH_NEXT_LINKS messages) */
                /* Must return 1 if these messages are to be sent from VISSIM!         */
    case DRIVER_DATA_VEH_NEXT_LINKS         :
    case DRIVER_DATA_VEH_ACTIVE_LANE_CHANGE :
    case DRIVER_DATA_VEH_REL_TARGET_LANE    :
    case DRIVER_DATA_NVEH_ID                :
    case DRIVER_DATA_NVEH_LANE_ANGLE        :
    case DRIVER_DATA_NVEH_LATERAL_POSITION  :
    case DRIVER_DATA_NVEH_DISTANCE          :
    case DRIVER_DATA_NVEH_REL_VELOCITY      :
    case DRIVER_DATA_NVEH_ACCELERATION      :
    case DRIVER_DATA_NVEH_LENGTH            :
    case DRIVER_DATA_NVEH_WIDTH             :
    case DRIVER_DATA_NVEH_WEIGHT            :
    case DRIVER_DATA_NVEH_TURNING_INDICATOR :
    case DRIVER_DATA_NVEH_CATEGORY          :
    case DRIVER_DATA_NVEH_LANE_CHANGE       :
    case DRIVER_DATA_NO_OF_LANES            :
    case DRIVER_DATA_LANE_WIDTH             :
    case DRIVER_DATA_LANE_END_DISTANCE      :
    case DRIVER_DATA_RADIUS                 :
    case DRIVER_DATA_MIN_RADIUS             :
    case DRIVER_DATA_DIST_TO_MIN_RADIUS     :
    case DRIVER_DATA_SLOPE                  :
    case DRIVER_DATA_SLOPE_AHEAD            :
    case DRIVER_DATA_SIGNAL_DISTANCE        :
    case DRIVER_DATA_SIGNAL_STATE           :
    case DRIVER_DATA_SIGNAL_STATE_START     :
    case DRIVER_DATA_SPEED_LIMIT_DISTANCE   :
    case DRIVER_DATA_SPEED_LIMIT_VALUE      :
      return 1;
    case DRIVER_DATA_DESIRED_ACCELERATION :
      desired_acceleration = double_value;
      return 1;
    case DRIVER_DATA_DESIRED_LANE_ANGLE :
      desired_lane_angle = double_value;
      return 1;
    case DRIVER_DATA_ACTIVE_LANE_CHANGE :
      active_lane_change = long_value;
      return 1;
    case DRIVER_DATA_REL_TARGET_LANE :
      rel_target_lane = long_value;
      return 1;
    default :
      return 1;
  }

}

/*--------------------------------------------------------------------------*/

DRIVERMODEL_API  int  DriverModelGetValue (long   type, 
                                           long   index1,
                                           long   index2,
                                           long   *long_value,
                                           double *double_value,
                                           char   **string_value)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
  /* Gets the value of a data object of type <type>, selected by <index1> */
  /* and possibly <index2>, and writes that value to <*double_value>,     */
  /* <*float_value> or <**string_value> (object and value selection       */
  /* depending on <type>).                                                */
  /* Return value is 1 on success, otherwise 0.                           */

  switch (type) {
    case DRIVER_DATA_STATUS :
      *long_value = 0;
      return 1;
    case DRIVER_DATA_VEH_TURNING_INDICATOR :
      *long_value = turning_indicator;
      return 1;
    case DRIVER_DATA_VEH_DESIRED_VELOCITY   :
      *double_value = desired_velocity;
      return 1;
    case DRIVER_DATA_VEH_COLOR :
      *long_value = vehicle_color;
      return 1;
    case DRIVER_DATA_WANTS_SUGGESTION :
      *long_value = 1;
      return 1;
    case DRIVER_DATA_DESIRED_ACCELERATION :
      *double_value = desired_acceleration;
      return 1;
    case DRIVER_DATA_DESIRED_LANE_ANGLE :
      *double_value = desired_lane_angle;
      return 1;
    case DRIVER_DATA_ACTIVE_LANE_CHANGE :
      *long_value = active_lane_change;
      return 1;
    case DRIVER_DATA_REL_TARGET_LANE :
      *long_value = rel_target_lane;
      return 1;
    case DRIVER_DATA_SIMPLE_LANECHANGE :
      *long_value = 1;
      return 1;
    default :
      return 0;
  }
}

/*==========================================================================*/

DRIVERMODEL_API  int  DriverModelExecuteCommand (long number)
{
  /* Executes the command <number> if that is available in the driver */
  /* module. Return value is 1 on success, otherwise 0.               */
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
  
  switch (number) {
    case DRIVER_COMMAND_INIT :
      return 1;
    case DRIVER_COMMAND_CREATE_DRIVER :
      return 1;
    case DRIVER_COMMAND_KILL_DRIVER :
      return 1;
    case DRIVER_COMMAND_MOVE_DRIVER :
      return 1;
    default :
      return 0;
  }
}

/*==========================================================================*/
/*  Ende of DriverModel.cpp                                                 */
/*==========================================================================*/
// CdrivermodelApp

BEGIN_MESSAGE_MAP(CdrivermodelApp, CWinApp)
END_MESSAGE_MAP()


// CdrivermodelApp construction

CdrivermodelApp::CdrivermodelApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CdrivermodelApp object

CdrivermodelApp theApp;


// CdrivermodelApp initialization

BOOL CdrivermodelApp::InitInstance()
{
	//sprintf(buffPP,"***InitInstance***Current counter number: %d",counter);
	// MessageBoxA(NULL,buffPP,"***InitInstance***",MB_OK);  //First
	// counter++;

	CWinApp::InitInstance();

	fs_config.open("./ConfigInfo.txt", fstream::in);

	getline(fs_config, lineread);
	getline(fs_config, lineread);

	//Get reference latitude and longitude coordinates
	getline(fs_config, lineread);
	sscanf(lineread.c_str(), "%lf %lf %lf", &lat_degree, &lat_minutes, &lat_seconds);

	getline(fs_config, lineread);
	sscanf(lineread.c_str(), "%lf %lf %lf", &lon_degree, &lon_minutes, &lon_seconds);

	getline(fs_config, lineread);
	sscanf(lineread.c_str(), "%lf", &altitude);

	altitude = altitude*0.3048;

	fs_config.close();


	longitude = geoPoint.dms2d(lon_degree, lon_minutes, lon_seconds) ;
	latitude = geoPoint.dms2d(lat_degree, lat_minutes, lat_seconds) ;

	geoPoint.init(longitude, latitude, altitude) ;


	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}
	fp = fopen(".\Emergence.log", "w");
	if (fp == NULL)
	{
		//MessageBox(NULL,"FILE pointer init failure!","xxx",MB_OK);
		exit(1);
	}
	fclose(fp);

	SOCKETSC_Init();


	return TRUE;
}
int CdrivermodelApp::ExitInstance()
{
	//sprintf(buffPP,"***ExitInstance***Current counter number: %d",counter);
	//MessageBoxA(NULL,buffPP,"***ExitInstance***",MB_OK);
	//counter++;

	SOCKETSC_Exit();
	return 1;
}
void CdrivermodelApp::OnAccept(void)
{

}

void CdrivermodelApp::OnClose(void)
{

}

void CdrivermodelApp::SOCKETSC_Init(void)
{
	/* Initializes the UDP communication. */


	WSADATA info;
	char    function_name[] = "SOCKETSC_Init";

	// Establish a connection, if this is the first call of SOCKETSC_Init.
	if (socketsc_sock == NULL) 
	{
		if (WSAStartup (MAKEWORD (2,2), &info) != 0)
		{
			sprintf(buffPP,"***WSAStartup***");
			MessageBoxA(NULL,buffPP,"***WSAStartup Failed***",MB_OK);  //Second
			//InternerFehler (function_name, "Cannot initialize WinSock!");
			return;
		}

		if ((socketsc_connect = establish ()) == INVALID_SOCKET)
		{ /* plug in the phone */
			return;
		}	



		strcpy(buffer,"Connected to Vissim..");

		size_t bufferSize = strlen((const char*)buffer);

		



		//if (write_data (socketsc_connect, buffer, bufferSize) != bufferSize) 
		//{
		//	//SOCKETSC_PrintDefectiveBuffer (function_name, "Error writing data for initialization!", buffer);
		//	return;
		//}


	}
}

void CdrivermodelApp::SOCKETSC_Exit(void)
{
	/* Cleans up the TCP/IP communication. */
	//sprintf(buffPP,"***SOCKETSC_Exit***Current counter number: %d",counter);
	//  MessageBoxA(NULL,buffPP,"***SOCKETSC_Exit***",MB_OK);
	//  counter++;
	if (socketsc_sock != NULL) {

		shutdown(socketsc_sock, SD_BOTH);
		closesocket (socketsc_sock);
		closesocket (socketsc_connect);
		WSACleanup ();
		socketsc_sock = NULL;
	}
}
