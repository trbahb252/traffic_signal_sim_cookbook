/*==========================================================================*/
/*  Diamond_3-Phase                                                        */
/*  Example model of a signalized conventional diamond interchange using VISSIM*/
/*                                                                          */
/*  ======================================================================  */
/* This model was developed by Hongmin (Tracy) Zhou @ Texas A&M Transportation Institute*/

/* STOP! PLEASE READ THE DISCLAIMER.                                       */
/* This program will be delivered "AS IS". GPL open-source license applies */
/* This program depends on the APIs provided by PTV. The author comsumes no */
/* responsiblity of PTV's API changes in the future.                        */
/* Users are encouraged to ask questions in the Linkedin Traffic Sig CookBook formum*/
/*==========================================================================*/  